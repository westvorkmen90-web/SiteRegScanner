package com.siteregscanner.scan

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.CreationExtras
import com.siteregscanner.data.AppDatabase
import com.siteregscanner.data.Scan
import com.siteregscanner.data.Site
import com.siteregscanner.export.XlsExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MutableStateFlow
import kotlinx.coroutines.StateFlow
import kotlinx.coroutines.asStateFlow
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.net.URI
import java.util.concurrent.atomic.AtomicInteger

data class ScanState(
    val running: Boolean = false,
    val progress: Float = 0f,
    val message: String = "",
    val scanned: Int = 0,
    val found: Int = 0,
    val open: Int = 0
)

class ScannerViewModel(
    private val db: AppDatabase,
    app: Application
) : AndroidViewModel(app) {

    val sites = db.siteDao().observeOpen()
    val allSites = db.siteDao().observeAll()
    val scans = db.scanDao().observe()

    private val _state = MutableStateFlow(ScanState())
    val state: StateFlow<ScanState> = _state.asStateFlow()

    private val provider: SearchProvider = DuckDuckGoProvider()
    private val scanner = SiteScanner()

    fun startSearch(
        query: String,
        limit: Int
    ) {
        if (_state.value.running || query.isBlank()) {
            return
        }

        viewModelScope.launch {
            val started = System.currentTimeMillis()

            val scanId = withContext(Dispatchers.IO) {
                db.scanDao().insert(
                    Scan(
                        query = query,
                        startedAt = started
                    )
                )
            }

            _state.value = ScanState(
                running = true,
                message = "Получение поисковой выдачи…"
            )

            try {
                val hits = withContext(Dispatchers.IO) {
                    provider.search(
                        query,
                        limit.coerceIn(1, 300)
                    )
                }

                if (hits.isEmpty()) {
                    withContext(Dispatchers.IO) {
                        db.scanDao().finish(
                            scanId,
                            System.currentTimeMillis(),
                            0,
                            0,
                            "DONE"
                        )
                    }

                    _state.value = ScanState(
                        running = false,
                        progress = 1f,
                        message = "Поисковая выдача пуста"
                    )

                    return@launch
                }

                val openCounter = AtomicInteger(0)
                val semaphore = Semaphore(6)

                coroutineScope {
                    hits.mapIndexed { index, hit ->

                        async(Dispatchers.IO) {

                            semaphore.withPermit {

                                val result = scanner.scan(hit)

                                if (
                                    result?.open == true &&
                                    result.registrationUrl != null
                                ) {

                                    val domain = runCatching {
                                        URI(hit.url)
                                            .host
                                            .orEmpty()
                                    }.getOrDefault("")

                                    val existing = db.siteDao()
                                        .findByUrl(hit.url)

                                    if (existing == null) {

                                        db.siteDao().insert(
                                            Site(
                                                url = hit.url,
                                                domain = domain,
                                                title = result.title.ifBlank {
                                                    hit.title
                                                },
                                                type = result.type,
                                                registrationUrl =
                                                    result.registrationUrl,
                                                searchQuery = query
                                            )
                                        )

                                    } else {

                                        db.siteDao().update(
                                            existing.id,
                                            System.currentTimeMillis(),
                                            "OPEN",
                                            result.registrationUrl,
                                            result.title.ifBlank {
                                                existing.title
                                            },
                                            result.type
                                        )
                                    }

                                    openCounter.incrementAndGet()
                                }

                                withContext(Dispatchers.Main) {

                                    _state.value =
                                        _state.value.copy(
                                            running = true,
                                            progress =
                                                (index + 1).toFloat() /
                                                        hits.size,
                                            scanned = index + 1,
                                            found = hits.size,
                                            open = openCounter.get(),
                                            message =
                                                "Проверено ${
                                                    index + 1
                                                } из ${hits.size}"
                                        )
                                }
                            }
                        }
                    }.awaitAll()
                }

                withContext(Dispatchers.IO) {
                    db.scanDao().finish(
                        scanId,
                        System.currentTimeMillis(),
                        hits.size,
                        openCounter.get(),
                        "DONE"
                    )
                }

                _state.value =
                    _state.value.copy(
                        running = false,
                        progress = 1f,
                        message =
                            "Готово. Открытая регистрация: ${
                                openCounter.get()
                            }"
                    )

            } catch (t: Throwable) {

                withContext(Dispatchers.IO) {
                    db.scanDao().finish(
                        scanId,
                        System.currentTimeMillis(),
                        0,
                        0,
                        "ERROR"
                    )
                }

                _state.value =
                    _state.value.copy(
                        running = false,
                        message =
                            "Ошибка: ${
                                t.message ?: "неизвестная ошибка"
                            }"
                    )
            }
        }
    }

    fun exportXls() {

        viewModelScope.launch(Dispatchers.IO) {

            val intent = XlsExporter
                .export(
                    getApplication(),
                    db.siteDao().getOpen()
                )
                .apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }

            getApplication<Application>()
                .startActivity(
                    Intent
                        .createChooser(
                            intent,
                            "Сохранить XLS"
                        )
                        .addFlags(
                            Intent.FLAG_ACTIVITY_NEW_TASK
                        )
                )
        }
    }

    companion object {

        fun factory(
            db: AppDatabase
        ): ViewModelProvider.Factory {

            return object : ViewModelProvider.Factory {

                override fun <T : ViewModel> create(
                    modelClass: Class<T>,
                    extras: CreationExtras
                ): T {

                    val application =
                        extras[
                            ViewModelProvider
                                .AndroidViewModelFactory
                                .APPLICATION_KEY
                        ]
                            ?: error(
                                "Application unavailable"
                            )

                    if (
                        modelClass.isAssignableFrom(
                            ScannerViewModel::class.java
                        )
                    ) {

                        @Suppress("UNCHECKED_CAST")
                        return ScannerViewModel(
                            db,
                            application
                        ) as T
                    }

                    throw IllegalArgumentException(
                        "Unknown ViewModel class: ${
                            modelClass.name
                        }"
                    )
                }
            }
        }
    }
}package com.siteregscanner.scan

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.CreationExtras
import com.siteregscanner.data.AppDatabase
import com.siteregscanner.data.Scan
import com.siteregscanner.data.Site
import com.siteregscanner.export.XlsExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MutableStateFlow
import kotlinx.coroutines.StateFlow
import kotlinx.coroutines.asStateFlow
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.net.URI
import java.util.concurrent.atomic.AtomicInteger

data class ScanState(
    val running: Boolean = false,
    val progress: Float = 0f,
    val message: String = "",
    val scanned: Int = 0,
    val found: Int = 0,
    val open: Int = 0
)

class ScannerViewModel(
    private val db: AppDatabase,
    app: Application
) : AndroidViewModel(app) {

    val sites = db.siteDao().observeOpen()
    val allSites = db.siteDao().observeAll()
    val scans = db.scanDao().observe()

    private val _state = MutableStateFlow(ScanState())
    val state: StateFlow<ScanState> = _state.asStateFlow()

    private val provider: SearchProvider = DuckDuckGoProvider()
    private val scanner = SiteScanner()

    fun startSearch(
        query: String,
        limit: Int
    ) {
        if (_state.value.running || query.isBlank()) {
            return
        }

        viewModelScope.launch {
            val started = System.currentTimeMillis()

            val scanId = withContext(Dispatchers.IO) {
                db.scanDao().insert(
                    Scan(
                        query = query,
                        startedAt = started
                    )
                )
            }

            _state.value = ScanState(
                running = true,
                message = "Получение поисковой выдачи…"
            )

            try {
                val hits = withContext(Dispatchers.IO) {
                    provider.search(
                        query,
                        limit.coerceIn(1, 300)
                    )
                }

                if (hits.isEmpty()) {
                    withContext(Dispatchers.IO) {
                        db.scanDao().finish(
                            scanId,
                            System.currentTimeMillis(),
                            0,
                            0,
                            "DONE"
                        )
                    }

                    _state.value = ScanState(
                        running = false,
                        progress = 1f,
                        message = "Поисковая выдача пуста"
                    )

                    return@launch
                }

                val openCounter = AtomicInteger(0)
                val semaphore = Semaphore(6)

                coroutineScope {
                    hits.mapIndexed { index, hit ->

                        async(Dispatchers.IO) {

                            semaphore.withPermit {

                                val result = scanner.scan(hit)

                                if (
                                    result?.open == true &&
                                    result.registrationUrl != null
                                ) {

                                    val domain = runCatching {
                                        URI(hit.url)
                                            .host
                                            .orEmpty()
                                    }.getOrDefault("")

                                    val existing = db.siteDao()
                                        .findByUrl(hit.url)

                                    if (existing == null) {

                                        db.siteDao().insert(
                                            Site(
                                                url = hit.url,
                                                domain = domain,
                                                title = result.title.ifBlank {
                                                    hit.title
                                                },
                                                type = result.type,
                                                registrationUrl =
                                                    result.registrationUrl,
                                                searchQuery = query
                                            )
                                        )

                                    } else {

                                        db.siteDao().update(
                                            existing.id,
                                            System.currentTimeMillis(),
                                            "OPEN",
                                            result.registrationUrl,
                                            result.title.ifBlank {
                                                existing.title
                                            },
                                            result.type
                                        )
                                    }

                                    openCounter.incrementAndGet()
                                }

                                withContext(Dispatchers.Main) {

                                    _state.value =
                                        _state.value.copy(
                                            running = true,
                                            progress =
                                                (index + 1).toFloat() /
                                                        hits.size,
                                            scanned = index + 1,
                                            found = hits.size,
                                            open = openCounter.get(),
                                            message =
                                                "Проверено ${
                                                    index + 1
                                                } из ${hits.size}"
                                        )
                                }
                            }
                        }
                    }.awaitAll()
                }

                withContext(Dispatchers.IO) {
                    db.scanDao().finish(
                        scanId,
                        System.currentTimeMillis(),
                        hits.size,
                        openCounter.get(),
                        "DONE"
                    )
                }

                _state.value =
                    _state.value.copy(
                        running = false,
                        progress = 1f,
                        message =
                            "Готово. Открытая регистрация: ${
                                openCounter.get()
                            }"
                    )

            } catch (t: Throwable) {

                withContext(Dispatchers.IO) {
                    db.scanDao().finish(
                        scanId,
                        System.currentTimeMillis(),
                        0,
                        0,
                        "ERROR"
                    )
                }

                _state.value =
                    _state.value.copy(
                        running = false,
                        message =
                            "Ошибка: ${
                                t.message ?: "неизвестная ошибка"
                            }"
                    )
            }
        }
    }

    fun exportXls() {

        viewModelScope.launch(Dispatchers.IO) {

            val intent = XlsExporter
                .export(
                    getApplication(),
                    db.siteDao().getOpen()
                )
                .apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }

            getApplication<Application>()
                .startActivity(
                    Intent
                        .createChooser(
                            intent,
                            "Сохранить XLS"
                        )
                        .addFlags(
                            Intent.FLAG_ACTIVITY_NEW_TASK
                        )
                )
        }
    }

    companion object {

        fun factory(
            db: AppDatabase
        ): ViewModelProvider.Factory {

            return object : ViewModelProvider.Factory {

                override fun <T : ViewModel> create(
                    modelClass: Class<T>,
                    extras: CreationExtras
                ): T {

                    val application =
                        extras[
                            ViewModelProvider
                                .AndroidViewModelFactory
                                .APPLICATION_KEY
                        ]
                            ?: error(
                                "Application unavailable"
                            )

                    if (
                        modelClass.isAssignableFrom(
                            ScannerViewModel::class.java
                        )
                    ) {

                        @Suppress("UNCHECKED_CAST")
                        return ScannerViewModel(
                            db,
                            application
                        ) as T
                    }

                    throw IllegalArgumentException(
                        "Unknown ViewModel class: ${
                            modelClass.name
                        }"
                    )
                }
            }
        }
    }
}package com.siteregscanner.scan

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.CreationExtras
import com.siteregscanner.data.AppDatabase
import com.siteregscanner.data.Scan
import com.siteregscanner.data.Site
import com.siteregscanner.export.XlsExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MutableStateFlow
import kotlinx.coroutines.StateFlow
import kotlinx.coroutines.asStateFlow
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.net.URI
import java.util.concurrent.atomic.AtomicInteger

data class ScanState(
    val running: Boolean = false,
    val progress: Float = 0f,
    val message: String = "",
    val scanned: Int = 0,
    val found: Int = 0,
    val open: Int = 0
)

class ScannerViewModel(
    private val db: AppDatabase,
    app: Application
) : AndroidViewModel(app) {

    val sites = db.siteDao().observeOpen()
    val allSites = db.siteDao().observeAll()
    val scans = db.scanDao().observe()

    private val _state = MutableStateFlow(ScanState())
    val state: StateFlow<ScanState> = _state.asStateFlow()

    private val provider: SearchProvider = DuckDuckGoProvider()
    private val scanner = SiteScanner()

    fun startSearch(
        query: String,
        limit: Int
    ) {
        if (_state.value.running || query.isBlank()) {
            return
        }

        viewModelScope.launch {
            val started = System.currentTimeMillis()

            val scanId = withContext(Dispatchers.IO) {
                db.scanDao().insert(
                    Scan(
                        query = query,
                        startedAt = started
                    )
                )
            }

            _state.value = ScanState(
                running = true,
                message = "Получение поисковой выдачи…"
            )

            try {
                val hits = withContext(Dispatchers.IO) {
                    provider.search(
                        query,
                        limit.coerceIn(1, 300)
                    )
                }

                if (hits.isEmpty()) {
                    withContext(Dispatchers.IO) {
                        db.scanDao().finish(
                            scanId,
                            System.currentTimeMillis(),
                            0,
                            0,
                            "DONE"
                        )
                    }

                    _state.value = ScanState(
                        running = false,
                        progress = 1f,
                        message = "Поисковая выдача пуста"
                    )

                    return@launch
                }

                val openCounter = AtomicInteger(0)
                val semaphore = Semaphore(6)

                coroutineScope {
                    hits.mapIndexed { index, hit ->

                        async(Dispatchers.IO) {

                            semaphore.withPermit {

                                val result = scanner.scan(hit)

                                if (
                                    result?.open == true &&
                                    result.registrationUrl != null
                                ) {

                                    val domain = runCatching {
                                        URI(hit.url)
                                            .host
                                            .orEmpty()
                                    }.getOrDefault("")

                                    val existing = db.siteDao()
                                        .findByUrl(hit.url)

                                    if (existing == null) {

                                        db.siteDao().insert(
                                            Site(
                                                url = hit.url,
                                                domain = domain,
                                                title = result.title.ifBlank {
                                                    hit.title
                                                },
                                                type = result.type,
                                                registrationUrl =
                                                    result.registrationUrl,
                                                searchQuery = query
                                            )
                                        )

                                    } else {

                                        db.siteDao().update(
                                            existing.id,
                                            System.currentTimeMillis(),
                                            "OPEN",
                                            result.registrationUrl,
                                            result.title.ifBlank {
                                                existing.title
                                            },
                                            result.type
                                        )
                                    }

                                    openCounter.incrementAndGet()
                                }

                                withContext(Dispatchers.Main) {

                                    _state.value =
                                        _state.value.copy(
                                            running = true,
                                            progress =
                                                (index + 1).toFloat() /
                                                        hits.size,
                                            scanned = index + 1,
                                            found = hits.size,
                                            open = openCounter.get(),
                                            message =
                                                "Проверено ${
                                                    index + 1
                                                } из ${hits.size}"
                                        )
                                }
                            }
                        }
                    }.awaitAll()
                }

                withContext(Dispatchers.IO) {
                    db.scanDao().finish(
                        scanId,
                        System.currentTimeMillis(),
                        hits.size,
                        openCounter.get(),
                        "DONE"
                    )
                }

                _state.value =
                    _state.value.copy(
                        running = false,
                        progress = 1f,
                        message =
                            "Готово. Открытая регистрация: ${
                                openCounter.get()
                            }"
                    )

            } catch (t: Throwable) {

                withContext(Dispatchers.IO) {
                    db.scanDao().finish(
                        scanId,
                        System.currentTimeMillis(),
                        0,
                        0,
                        "ERROR"
                    )
                }

                _state.value =
                    _state.value.copy(
                        running = false,
                        message =
                            "Ошибка: ${
                                t.message ?: "неизвестная ошибка"
                            }"
                    )
            }
        }
    }

    fun exportXls() {

        viewModelScope.launch(Dispatchers.IO) {

            val intent = XlsExporter
                .export(
                    getApplication(),
                    db.siteDao().getOpen()
                )
                .apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }

            getApplication<Application>()
                .startActivity(
                    Intent
                        .createChooser(
                            intent,
                            "Сохранить XLS"
                        )
                        .addFlags(
                            Intent.FLAG_ACTIVITY_NEW_TASK
                        )
                )
        }
    }

    companion object {

        fun factory(
            db: AppDatabase
        ): ViewModelProvider.Factory {

            return object : ViewModelProvider.Factory {

                override fun <T : ViewModel> create(
                    modelClass: Class<T>,
                    extras: CreationExtras
                ): T {

                    val application =
                        extras[
                            ViewModelProvider
                                .AndroidViewModelFactory
                                .APPLICATION_KEY
                        ]
                            ?: error(
                                "Application unavailable"
                            )

                    if (
                        modelClass.isAssignableFrom(
                            ScannerViewModel::class.java
                        )
                    ) {

                        @Suppress("UNCHECKED_CAST")
                        return ScannerViewModel(
                            db,
                            application
                        ) as T
                    }

                    throw IllegalArgumentException(
                        "Unknown ViewModel class: ${
                            modelClass.name
                        }"
                    )
                }
            }
        }
    }
}