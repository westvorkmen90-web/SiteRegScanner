# SiteRegScanner 2.0

Android client for a self-hosted SearXNG instance.

Flow: SearXNG JSON -> URL list -> OkHttp -> Jsoup -> registration detection -> XLS.

The app itself has no application server. SearXNG is the external search service.

Important: the SearXNG instance must have JSON output enabled. Example:
`/search?q=forum&format=json`

Build with GitHub Actions workflow `.github/workflows/build-apk.yml`.
