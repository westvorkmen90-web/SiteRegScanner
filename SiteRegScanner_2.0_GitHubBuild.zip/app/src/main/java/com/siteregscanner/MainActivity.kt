package com.siteregscanner

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var server: EditText
    private lateinit var query: EditText
    private lateinit var limit: EditText
    private lateinit var status: TextView
    private lateinit var results: TextView
    private val scanner = Scanner()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        fun edit(hint: String, value: String = "") = EditText(this).apply {
            this.hint = hint
            setText(value)
            singleLine = true
        }
        server = edit("SearXNG server URL", "https://example.org")
        query = edit("Search query", "forum registration")
        limit = edit("Results per page", "20")
        val search = Button(this).apply { text = "СКАНИРОВАТЬ" }
        val export = Button(this).apply { text = "ЭКСПОРТ XLS" }
        status = TextView(this).apply { text = "Готово" }
        results = TextView(this).apply { setPadding(0, 16, 0, 16) }

        root.addView(server); root.addView(query); root.addView(limit)
        root.addView(search); root.addView(export); root.addView(status)
        val scroll = ScrollView(this).apply { addView(results) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        search.setOnClickListener {
            lifecycleScope.launch {
                search.isEnabled = false
                status.text = "Поиск и проверка..."
                try {
                    val n = limit.text.toString().toIntOrNull()?.coerceIn(1, 100) ?: 20
                    val found = scanner.searchAndScan(
                        server.text.toString(), query.text.toString(), n
                    )
                    status.text = "Готово. Открытая регистрация: ${found.size}"
                    results.text = found.joinToString("\n\n") {
                        "${it.title}\n${it.url}\nРегистрация: ${it.registrationUrl}"
                    }.ifBlank { "Подходящих площадок не найдено." }
                } catch (e: Exception) {
                    status.text = "Ошибка: ${e.message}"
                } finally { search.isEnabled = true }
            }
        }

        export.setOnClickListener {
            try {
                val uri = XlsExporter.export(this, scanner.items)
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/vnd.ms-excel"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(Intent.createChooser(intent, "Сохранить XLS"))
            } catch (e: Exception) {
                Toast.makeText(this, "Ошибка XLS: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
}
