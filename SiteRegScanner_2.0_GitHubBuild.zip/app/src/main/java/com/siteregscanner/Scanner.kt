package com.siteregscanner

import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import org.jsoup.Jsoup
import java.net.URI
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class SiteResult(
    val title: String,
    val url: String,
    val registrationUrl: String,
    val type: String
)

class Scanner {
    val items = mutableListOf<SiteResult>()
    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    suspend fun searchAndScan(serverUrl: String, query: String, limit: Int): List<SiteResult> {
        require(serverUrl.isNotBlank()) { "Укажите URL SearXNG" }
        require(query.isNotBlank()) { "Введите поисковый запрос" }

        val base = serverUrl.trimEnd('/')
        val url = "$base/search?q=${URLEncoder.encode(query, "UTF-8")}&format=json&language=all"
        val request = Request.Builder().url(url).get().build()
        val body = withContext(Dispatchers.IO) {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) error("SearXNG HTTP ${response.code}")
                response.body?.string() ?: error("Пустой ответ SearXNG")
            }
        }

        val arr = JSONObject(body).optJSONArray("results") ?: return emptyList()
        val candidates = (0 until minOf(arr.length(), limit)).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val u = o.optString("url")
            if (u.startsWith("http")) SiteResult(o.optString("title", u), u, "", "site") else null
        }.distinctBy { runCatching { URI(it.url).host }.getOrNull() ?: it.url }

        val checked = coroutineScope {
            candidates.map { async(Dispatchers.IO) { detectRegistration(it) } }.awaitAll().filterNotNull()
        }
        synchronized(items) { items.clear(); items.addAll(checked.distinctBy { it.url }) }
        return items.toList()
    }

    private fun detectRegistration(candidate: SiteResult): SiteResult? {
        return try {
            val request = Request.Builder()
                .url(candidate.url)
                .header("User-Agent", "SiteRegScanner/2.0")
                .build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val html = response.body?.string()?.take(1_500_000) ?: return null
                val doc = Jsoup.parse(html, candidate.url)
                val keywords = listOf(
                    "register", "registration", "sign up", "signup",
                    "create account", "join", "регистрация", "создать аккаунт"
                )
                val match = doc.select("a[href], form, input, button").firstOrNull { el ->
                    val text = (el.text() + " " + el.attr("href") + " " +
                            el.attr("name") + " " + el.attr("id") + " " +
                            el.attr("action")).lowercase()
                    keywords.any { text.contains(it) }
                } ?: return null
                val href = match.attr("abs:href").ifBlank { match.attr("abs:action") }
                    .ifBlank { candidate.url }
                val fields = doc.select(
                    "input[type=email], input[name*=email], input[name*=user], " +
                    "input[name*=login], input[type=password]"
                )
                if (!fields.isNotEmpty() && match.tagName() == "form") return null
                SiteResult(
                    doc.title().ifBlank { candidate.title },
                    candidate.url,
                    href,
                    detectType(doc)
                )
            }
        } catch (_: Exception) { null }
    }

    private fun detectType(doc: org.jsoup.nodes.Document): String {
        val text = doc.text().lowercase()
        return when {
            listOf("forum", "board", "форум").any { text.contains(it) } -> "forum"
            listOf("guestbook", "гостевая книга").any { text.contains(it) } -> "guestbook"
            listOf("blog", "блог").any { text.contains(it) } -> "blog"
            else -> "site"
        }
    }
}
