package com.siteregscanner

import android.content.Context
import androidx.core.content.FileProvider
import org.apache.poi.hssf.usermodel.HSSFWorkbook
import java.io.File

object XlsExporter {
    fun export(context: Context, items: List<SiteResult>) = run {
        val file = File(context.cacheDir, "SiteRegScanner_results.xls")
        HSSFWorkbook().use { workbook ->
            val sheet = workbook.createSheet("Sites")
            listOf("Title", "URL", "Domain", "Registration URL", "Type").forEachIndexed { i, v ->
                sheet.createRow(0).createCell(i).setCellValue(v)
            }
            items.forEachIndexed { index, item ->
                val row = sheet.createRow(index + 1)
                row.createCell(0).setCellValue(item.title)
                row.createCell(1).setCellValue(item.url)
                row.createCell(2).setCellValue(runCatching {
                    java.net.URI(item.url).host ?: ""
                }.getOrDefault(""))
                row.createCell(3).setCellValue(item.registrationUrl)
                row.createCell(4).setCellValue(item.type)
            }
            file.outputStream().use { workbook.write(it) }
        }
        FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
    }
}
