#!/usr/bin/env bash
set -e
gradle wrapper --gradle-version 8.11.1
