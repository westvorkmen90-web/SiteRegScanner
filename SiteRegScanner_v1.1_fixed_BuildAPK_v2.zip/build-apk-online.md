# Как получить APK онлайн

## GitHub Actions — бесплатно для небольших проектов

GitHub Actions умеет запускать Gradle-сборки на GitHub-hosted runner и сохранять APK как artifact.

1. Создайте репозиторий GitHub.
2. Загрузите содержимое этого проекта.
3. Откройте вкладку **Actions**.
4. Выберите **Build Android APK**.
5. Нажмите **Run workflow**.
6. После завершения откройте workflow run.
7. В разделе **Artifacts** скачайте `SiteRegScanner-debug-apk`.

## Codemagic

Codemagic также поддерживает native Android/Gradle и имеет бесплатный месячный лимит build minutes. Можно подключить репозиторий GitHub и настроить Android workflow.

## Release

Workflow `Build Release APK` создаёт release APK. Для распространения за пределами тестирования его следует подписать собственным Android keystore. Debug APK подходит для личного тестирования.

## Локально

В Android Studio откройте проект и выполните Build → Build APK(s).

CLI:
`./gradlew :app:assembleDebug`
