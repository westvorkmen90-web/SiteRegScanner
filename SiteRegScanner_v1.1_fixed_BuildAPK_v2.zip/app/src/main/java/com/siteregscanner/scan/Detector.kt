package com.siteregscanner.scan
import org.jsoup.Jsoup
import java.util.Locale

data class RegistrationResult(val open:Boolean,val registrationUrl:String?,val title:String,val type:String,val confidence:Int)

object RegistrationDetector {
    private val linkWords=listOf("register","registration","signup","sign up","create account","create an account","join","регистрация","зарегистрироваться","создать аккаунт")
    private val closedWords=listOf("registration is closed","registration closed","signups are disabled","sign up is disabled","registration disabled","invite only","registration unavailable","регистрация закрыта","регистрация отключена","регистрация недоступна","только по приглашению")
    private val fieldWords=listOf("password","confirm password","username","email","пароль","подтвердите пароль","имя пользователя","электронная почта")
    fun detect(base:String,html:String):RegistrationResult{
        val d=Jsoup.parse(html,base); val body=d.body()?.text()?.lowercase(Locale.ROOT).orEmpty()
        val type=when{
            listOf("phpbb","vbulletin","bbpress","forum","форум","discussion board").any(body::contains)->"Форум"
            listOf("guestbook","гостевая книга").any(body::contains)->"Гостевая книга"
            listOf("wordpress","blog","блог").any(body::contains)->"Блог"
            else->"Сайт"
        }
        if(closedWords.any(body::contains)) return RegistrationResult(false,null,d.title(),type,100)
        val links=d.select("a[href]").mapNotNull{a->
            val t="${a.text()} ${a.attr("href")}".lowercase(Locale.ROOT)
            if(linkWords.any(t::contains)) a.absUrl("href").takeIf{it.startsWith("http")} else null
        }.distinct()
        val formScore=d.select("form").sumOf{f->
            val t="${f.text()} ${f.html()}".lowercase(Locale.ROOT)
            fieldWords.count{t.contains(it)}
        }
        val pageLooks=linkWords.any("${d.title()} ${d.location()}".lowercase(Locale.ROOT)::contains)
        val openUrl=links.firstOrNull()
        val confidence=when{
            openUrl!=null && formScore>=2->95
            openUrl!=null->75
            pageLooks && formScore>=2->90
            else->0
        }
        return RegistrationResult(confidence>=70,if(pageLooks && formScore>=2) base else openUrl,d.title(),type,confidence)
    }
}
