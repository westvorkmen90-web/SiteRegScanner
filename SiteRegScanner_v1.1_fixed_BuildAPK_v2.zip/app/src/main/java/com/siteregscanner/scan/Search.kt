package com.siteregscanner.scan
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.TimeUnit

data class SearchHit(val url:String,val title:String)
interface SearchProvider { suspend fun search(query:String,limit:Int):List<SearchHit> }

class DuckDuckGoProvider:SearchProvider{
    private val client=OkHttpClient.Builder().callTimeout(20,TimeUnit.SECONDS).build()
    override suspend fun search(query:String,limit:Int):List<SearchHit>{
        val q=URLEncoder.encode(query,StandardCharsets.UTF_8.toString())
        val req=Request.Builder().url("https://html.duckduckgo.com/html/?q=$q")
            .header("User-Agent","Mozilla/5.0 (Android) SiteRegScanner/1.0").build()
        client.newCall(req).execute().use{r->
            if(!r.isSuccessful) error("Поиск: HTTP ${r.code}")
            val doc=Jsoup.parse(r.body?.string().orEmpty())
            return doc.select("a.result__a").mapNotNull{a->
                val u=a.absUrl("href").ifBlank{a.attr("href")}
                if(u.startsWith("http")) SearchHit(u,a.text()) else null
            }.distinctBy{normalize(it.url)}.take(limit)
        }
    }
    private fun normalize(u:String)=u.substringBefore("#").trimEnd('/')
}
