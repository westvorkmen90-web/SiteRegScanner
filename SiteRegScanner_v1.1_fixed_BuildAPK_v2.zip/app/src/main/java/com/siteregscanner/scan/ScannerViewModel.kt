package com.siteregscanner.scan
import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.CreationExtras
import com.siteregscanner.data.*
import com.siteregscanner.export.XlsExporter
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.sync.withPermit
import java.net.URI
import java.util.concurrent.atomic.AtomicInteger

data class ScanState(val running:Boolean=false,val progress:Float=0f,val message:String="",val scanned:Int=0,val found:Int=0,val open:Int=0)
class ScannerViewModel(private val db:AppDatabase,app:Application):AndroidViewModel(app){
    val sites=db.siteDao().observeOpen()
    val allSites=db.siteDao().observeAll()
    val scans=db.scanDao().observe()
    private val _state=MutableStateFlow(ScanState())
    val state:StateFlow<ScanState> = _state.asStateFlow()
    private val provider:SearchProvider=DuckDuckGoProvider()
    private val scanner=SiteScanner()

    fun startSearch(query:String,limit:Int){
        if(_state.value.running||query.isBlank())return
        viewModelScope.launch{
            val started=System.currentTimeMillis(); val scanId=withContext(Dispatchers.IO){db.scanDao().insert(Scan(query=query,startedAt=started))}
            _state.value=ScanState(running=true,message="Получение поисковой выдачи…")
            try{
                val hits=withContext(Dispatchers.IO){provider.search(query,limit.coerceIn(1,300))}
                val openCounter=AtomicInteger(0)
                val semaphore=kotlinx.coroutines.sync.Semaphore(6)
                coroutineScope{
                    hits.mapIndexed{idx,hit->async(Dispatchers.IO){
                        semaphore.withPermit{
                            val res=scanner.scan(hit)
                            if(res?.open==true&&res.registrationUrl!=null){
                                val domain=runCatching{URI(hit.url).host.orEmpty()}.getOrDefault("")
                                val ex=db.siteDao().findByUrl(hit.url)
                                if(ex==null) db.siteDao().insert(Site(url=hit.url,domain=domain,title=res.title.ifBlank{hit.title},type=res.type,registrationUrl=res.registrationUrl,searchQuery=query))
                                else db.siteDao().update(ex.id,System.currentTimeMillis(),"OPEN",res.registrationUrl,res.title.ifBlank{ex.title},res.type)
                                openCounter.incrementAndGet()
                            }
                            withContext(Dispatchers.Main){
                                _state.value=_state.value.copy(running=true,progress=(idx+1).toFloat()/hits.size,scanned=idx+1,found=hits.size,open=openCounter.get(),message="Проверено ${idx+1} из ${hits.size}")
                            }
                        }
                    }}.awaitAll()
                }
                withContext(Dispatchers.IO){db.scanDao().finish(scanId,System.currentTimeMillis(),hits.size,openCounter.get(),"DONE")}
                _state.value=_state.value.copy(running=false,progress=1f,message="Готово. Открытая регистрация: ${openCounter.get()}")
            }catch(t:Throwable){
                withContext(Dispatchers.IO){db.scanDao().finish(scanId,System.currentTimeMillis(),0,0,"ERROR")}
                _state.value=_state.value.copy(running=false,message="Ошибка: ${t.message?: "неизвестная ошибка"}")
            }
        }
    }
    fun exportXls(){
        viewModelScope.launch(Dispatchers.IO){
            val intent=XlsExporter.export(getApplication(),db.siteDao().getOpen()).apply{addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)}
            getApplication<Application>().startActivity(Intent.createChooser(intent,"Сохранить XLS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
    companion object{
        fun factory(db:AppDatabase)=object:ViewModelProvider.Factory{
            override fun <T:androidx.lifecycle.ViewModel> create(modelClass:Class<T>,extras:CreationExtras):T{
                val app=extras[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY]?:error("Application unavailable")
                @Suppress("UNCHECKED_CAST") return ScannerViewModel(db,app) as T
            }
        }
    }
}
