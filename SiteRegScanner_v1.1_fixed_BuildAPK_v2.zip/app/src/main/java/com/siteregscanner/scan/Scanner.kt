package com.siteregscanner.scan
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

class SiteScanner{
    private val client=OkHttpClient.Builder().followRedirects(true).followSslRedirects(true)
        .callTimeout(20,TimeUnit.SECONDS).build()
    suspend fun scan(hit:SearchHit):RegistrationResult?=runCatching{
        val req=Request.Builder().url(hit.url).header("User-Agent","Mozilla/5.0 (Android) SiteRegScanner/1.0").build()
        client.newCall(req).execute().use{r->
            if(!r.isSuccessful)return null
            val body=r.body?.string().orEmpty(); if(body.isBlank())return null
            RegistrationDetector.detect(hit.url,body)
        }
    }.getOrNull()
}
