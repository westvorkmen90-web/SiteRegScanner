package com.siteregscanner
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.siteregscanner.data.*
import com.siteregscanner.scan.ScannerViewModel
import com.siteregscanner.ui.AppTheme
import java.text.SimpleDateFormat
import java.util.*

class MainActivity:ComponentActivity(){
    override fun onCreate(b:Bundle?){super.onCreate(b);val db=AppDatabase.get(this);setContent{AppTheme{App(viewModel(factory=ScannerViewModel.factory(db)),::openUrl)}}}
    private fun openUrl(u:String){runCatching{startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)))}}
}
private enum class Tab{SEARCH,RESULTS,HISTORY,SETTINGS}
@Composable fun App(vm:ScannerViewModel,open:(String)->Unit){
    var tab by remember{mutableStateOf(Tab.SEARCH)}
    val sites by vm.sites.collectAsState(initial=emptyList())
    val all by vm.allSites.collectAsState(initial=emptyList())
    val scans by vm.scans.collectAsState(initial=emptyList())
    val state by vm.state.collectAsState()
    Scaffold(bottomBar={NavigationBar{
        Tab.values().forEach{t->NavigationBarItem(selected=tab==t,onClick={tab=t},icon={},label={Text(when(t){Tab.SEARCH->"Поиск";Tab.RESULTS->"Результаты";Tab.HISTORY->"История";Tab.SETTINGS->"Настройки"})})}
    }}){pad->
        Column(Modifier.padding(pad).fillMaxSize().padding(16.dp)){
            when(tab){
                Tab.SEARCH->SearchPage(state,{q,n->vm.startSearch(q,n)},vm::exportXls)
                Tab.RESULTS->ResultsPage(sites,open)
                Tab.HISTORY->HistoryPage(scans,all)
                Tab.SETTINGS->SettingsPage()
            }
        }
    }
}
@Composable fun SearchPage(state:com.siteregscanner.scan.ScanState,start:(String,Int)->Unit,export:()->Unit){
    var q by remember{mutableStateOf("")};var n by remember{mutableStateOf("50")}
    Text("SiteReg Scanner",style=MaterialTheme.typography.headlineMedium);Spacer(Modifier.height(8.dp))
    Text("Поиск площадок с доступной регистрацией",style=MaterialTheme.typography.bodyMedium);Spacer(Modifier.height(12.dp))
    OutlinedTextField(q,{q=it},label={Text("Поисковый запрос")},modifier=Modifier.fillMaxWidth(),singleLine=true)
    Spacer(Modifier.height(8.dp))
    OutlinedTextField(n,{n=it.filter(Char::isDigit).take(3)},label={Text("Количество результатов")},modifier=Modifier.fillMaxWidth(),singleLine=true)
    Spacer(Modifier.height(8.dp))
    Button({start(q,n.toIntOrNull()?:50)},enabled=q.isNotBlank()&&!state.running,modifier=Modifier.fillMaxWidth()){Text(if(state.running)"Сканирование…" else "НАЧАТЬ СКАНИРОВАНИЕ")}
    Spacer(Modifier.height(8.dp))
    OutlinedButton(export,enabled=!state.running,modifier=Modifier.fillMaxWidth()){Text("ЭКСПОРТ XLS")}
    Spacer(Modifier.height(12.dp))
    LinearProgressIndicator({state.progress},Modifier.fillMaxWidth())
    Text(state.message,Modifier.padding(top=8.dp))
}
@Composable fun ResultsPage(sites:List<Site>,open:(String)->Unit){
    Text("Результаты",style=MaterialTheme.typography.headlineMedium);Text("Только регистрация OPEN: ${sites.size}")
    LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxSize().padding(top=10.dp)){items(sites,key={it.id}){s->
        ElevatedCard(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){
            Text(s.title.ifBlank{s.domain},style=MaterialTheme.typography.titleMedium);Text(s.domain)
            Text("Тип: ${s.type}");Text("🟢 Регистрация доступна");Text(s.registrationUrl)
            TextButton({open(s.registrationUrl)}){Text("Открыть регистрацию")}
        }}
    }}
}
@Composable fun HistoryPage(scans:List<Scan>,all:List<Site>){
    Text("История",style=MaterialTheme.typography.headlineMedium)
    Text("Всего найдено записей: ${all.size}")
    LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxSize().padding(top=10.dp)){items(scans,key={it.id}){s->
        ElevatedCard(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){
            Text(s.query,style=MaterialTheme.typography.titleMedium)
            Text(SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(Date(s.startedAt)))
            Text("Результатов: ${s.foundCount}; открытая регистрация: ${s.openCount}; ${s.status}")
        }}
    }}
}
@Composable fun SettingsPage(){
    Text("Настройки",style=MaterialTheme.typography.headlineMedium);Spacer(Modifier.height(12.dp))
    Text("Параллельных проверок: 6");Text("HTTP timeout: 20 секунд");Text("Локальная база: Room / SQLite")
    Text("Экспорт: только XLS (.xls)",modifier=Modifier.padding(top=8.dp))
    Text("Примечание: поисковые системы могут применять CAPTCHA и ограничения к автоматическим запросам.",modifier=Modifier.padding(top=16.dp))
}
