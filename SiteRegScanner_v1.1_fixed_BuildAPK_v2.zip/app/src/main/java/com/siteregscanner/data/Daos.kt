package com.siteregscanner.data
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao interface SiteDao {
    @Query("SELECT * FROM sites WHERE status='OPEN' ORDER BY lastChecked DESC") fun observeOpen():Flow<List<Site>>
    @Query("SELECT * FROM sites ORDER BY lastChecked DESC") fun observeAll():Flow<List<Site>>
    @Insert(onConflict=OnConflictStrategy.IGNORE) suspend fun insert(site:Site):Long
    @Query("SELECT * FROM sites WHERE url=:url LIMIT 1") suspend fun findByUrl(url:String):Site?
    @Query("UPDATE sites SET lastChecked=:time,status=:status,registrationUrl=:registrationUrl,title=:title,type=:type WHERE id=:id")
    suspend fun update(id:Long,time:Long,status:String,registrationUrl:String,title:String,type:String)
    @Query("SELECT * FROM sites WHERE status='OPEN' ORDER BY lastChecked DESC") suspend fun getOpen():List<Site>
}
@Dao interface ScanDao {
    @Insert suspend fun insert(scan:Scan):Long
    @Query("SELECT * FROM scans ORDER BY startedAt DESC") fun observe():Flow<List<Scan>>
    @Query("UPDATE scans SET finishedAt=:finish,foundCount=:found,openCount=:open,status=:status WHERE id=:id")
    suspend fun finish(id:Long,finish:Long,found:Int,open:Int,status:String)
}
