package com.siteregscanner.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName="sites")
data class Site(
    @PrimaryKey(autoGenerate=true) val id:Long=0,
    val url:String,
    val domain:String,
    val title:String,
    val type:String,
    val registrationUrl:String,
    val status:String="OPEN",
    val firstSeen:Long=System.currentTimeMillis(),
    val lastChecked:Long=System.currentTimeMillis(),
    val searchQuery:String=""
)

@Entity(tableName="scans")
data class Scan(
    @PrimaryKey(autoGenerate=true) val id:Long=0,
    val query:String,
    val startedAt:Long,
    val finishedAt:Long?=null,
    val foundCount:Int=0,
    val openCount:Int=0,
    val status:String="RUNNING"
)
