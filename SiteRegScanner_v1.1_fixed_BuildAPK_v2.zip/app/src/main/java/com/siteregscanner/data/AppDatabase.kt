package com.siteregscanner.data
import android.content.Context
import androidx.room.*
@Database(entities=[Site::class,Scan::class],version=1,exportSchema=false)
abstract class AppDatabase:RoomDatabase(){
    abstract fun siteDao():SiteDao
    abstract fun scanDao():ScanDao
    companion object {
        @Volatile private var instance:AppDatabase?=null
        fun get(c:Context):AppDatabase=instance?:synchronized(this){
            instance?:Room.databaseBuilder(c.applicationContext,AppDatabase::class.java,"site_reg_scanner.db").build().also{instance=it}
        }
    }
}
