package com.siteregscanner.export
import android.content.Context
import androidx.core.content.FileProvider
import android.content.Intent
import com.siteregscanner.data.Site
import org.apache.poi.hssf.usermodel.HSSFWorkbook
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
object XlsExporter{
    fun export(context:Context,sites:List<Site>):Intent{
        val stamp=SimpleDateFormat("yyyy-MM-dd_HH-mm",Locale.US).format(Date())
        val dir=File(context.cacheDir,"exports").apply{mkdirs()}
        val file=File(dir,"SiteReg_$stamp.xls")
        HSSFWorkbook().use{wb->
            val sh=wb.createSheet("Open registrations")
            val h=listOf("URL","Название","Тип","Registration URL","Дата проверки","Уверенность")
            h.forEachIndexed{i,v->sh.createRow(0).createCell(i).setCellValue(v)}
            sites.filter{it.status=="OPEN"}.forEachIndexed{idx,s->
                val r=sh.createRow(idx+1)
                r.createCell(0).setCellValue(s.url); r.createCell(1).setCellValue(s.title)
                r.createCell(2).setCellValue(s.type); r.createCell(3).setCellValue(s.registrationUrl)
                r.createCell(4).setCellValue(SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(Date(s.lastChecked)))
                r.createCell(5).setCellValue("Подтверждена")
            }
            h.indices.forEach{sh.setColumnWidth(it,8500)}
            FileOutputStream(file).use{wb.write(it)}
        }
        return Intent(Intent.ACTION_SEND).apply{
            type="application/vnd.ms-excel"
            putExtra(Intent.EXTRA_STREAM,FileProvider.getUriForFile(context,"${context.packageName}.files",file))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }
}
