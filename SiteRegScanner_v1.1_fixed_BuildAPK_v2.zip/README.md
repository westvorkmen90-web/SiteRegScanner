# SiteReg Scanner 1.1 — Build APK

Готовый Android Gradle-проект для сборки APK.

Стек:
- Kotlin
- Jetpack Compose
- Room / SQLite
- OkHttp + Jsoup
- Apache POI HSSF
- JDK 17
- Android SDK 35
- Gradle 8.11.1

Функции:
- Поиск
- Параллельное сканирование
- Проверка доступности регистрации
- Результаты
- История
- Настройки
- Только XLS экспорт

Для онлайн-сборки см. `build-apk-online.md`.
